@echo off
setlocal enabledelayedexpansion
title Alpha Execute - Installer

echo ==================================================
echo    Alpha Execute  -  VS Code Extension Installer
echo ==================================================
echo.

set "VSIX=%~dp0alpha-execute-1.0.0.vsix"

if not exist "%VSIX%" (
    echo [ERROR] Could not find %VSIX%
    echo.
    echo Make sure this installer is in the same folder as the .vsix file.
    echo.
    pause
    exit /b 1
)

echo [1/3] Locating VS Code...
set "CODE_EXE="

for %%L in (
    "%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe"
    "%ProgramFiles%\Microsoft VS Code\Code.exe"
    "%ProgramFiles(x86)%\Microsoft VS Code\Code.exe"
    "%USERPROFILE%\AppData\Roaming\Microsoft VS Code\Code.exe"
    "%USERPROFILE%\scoop\apps\vscode\current\Code.exe"
) do (
    if not defined CODE_EXE (
        if exist "%%~L" set "CODE_EXE=%%~L"
    )
)

if not defined CODE_EXE (
    for /f "delims=" %%i in ('where code.cmd 2^>nul') do (
        if not defined CODE_EXE set "CODE_EXE=%%i"
    )
)

if not defined CODE_EXE (
    echo [ERROR] VS Code was not found on this system.
    echo.
    echo Install VS Code first, then run this installer again:
    echo   https://code.visualstudio.com/
    echo.
    pause
    exit /b 1
)

echo Found: %CODE_EXE%

rem Code.exe only runs as a CLI when given cli.js (that's what code.cmd does).
rem Use the code.cmd shim when possible so the install always works.
set "CODE_DIR="
for %%d in ("%CODE_EXE%") do set "CODE_DIR=%%~dpd"
set "CLI="
if exist "%CODE_DIR%bin\code.cmd" set "CLI=%CODE_DIR%bin\code.cmd"
if not defined CLI set "CLI=%CODE_EXE%"

echo.
echo Using: %CLI%
echo.

rem Installing while VS Code is open can make a running instance flag the
rem extension for removal and delete it. So we close VS Code first.

set "WAS_RUNNING="
tasklist /fi "imagename eq Code.exe" | find /i "Code.exe" >nul 2>nul
if !errorlevel!==0 set "WAS_RUNNING=1"

if not defined WAS_RUNNING goto skipclose

echo [2/3] VS Code is currently open.
echo        It must be closed to install correctly.
echo        Save your work first.
echo.
set /p "CLOSE=        Close all VS Code windows and continue? (Y/N): "
if /i "%CLOSE%"=="y" goto doclose
echo.
echo [ABORTED] Close all VS Code windows, then run this installer again.
echo.
pause
exit /b 1

:doclose
echo Closing VS Code...
taskkill /im Code.exe >nul 2>nul
call :waitforclose
echo VS Code closed.
echo.

:skipclose
echo Installing extension (this may take a moment)...
echo.
call "%CLI%" --install-extension "%VSIX%" --force

if errorlevel 1 (
    echo.
    echo [ERROR] Installation failed.
    echo.
    pause
    exit /b 1
)

echo.
echo [3/3] Success! Alpha Execute was installed.
echo.
echo Checking VS Code has picked it up...
"%CLI%" --list-extensions | find /i "alpha.alpha-execute" >nul 2>nul
if errorlevel 1 (
    echo [WARNING] VS Code did not report it as installed yet.
    echo          Open VS Code and check the Extensions tab.
) else (
    echo Confirmed: alpha.alpha-execute is installed.
)

echo.
echo Opening VS Code...
start "" "%CODE_EXE%"
echo.
echo Done! Look for the orange "Alpha Execute" plug icon in the bottom
echo status bar, or find it under Extensions - Installed.
echo.
pause
exit /b 0

:waitforclose
timeout /t 1 /nobreak >nul
tasklist /fi "imagename eq Code.exe" | find /i "Code.exe" >nul 2>nul
if not errorlevel 1 goto waitforclose
exit /b 0

