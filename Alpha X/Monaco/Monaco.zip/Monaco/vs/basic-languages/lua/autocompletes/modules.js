define(["require", "exports"], function (require, exports) {
	Object.defineProperty(exports, "__esModule", { value: true });

	exports.autocompletes = {
		"Module": {
			"bit32": {},
			"coroutine": {},
			"debug": {
				__children__: {},
				__using__: ['libraries/debug'],
			},
			"oth": {
				__children__: {},
				__using__: ['libraries/oth'],
			},
			"raknet": {
				__children__: {},
				__using__: ['libraries/raknet'],
			},
			"math": {
				__children__: {},
				__using__: ['libraries/math'],
			},
			"os": {
				__children__: {},
				__using__: ['libraries/os'],
			},
			"crypt": {
				__children__: {},
				__using__: ['libraries/crypt'],
			},
			"Regex": {
				__children__: {},
				__using__: ['libraries/regex'],
			},
			"string": {},
			"table": {
				__children__: {},
				__using__: ['libraries/table'],
			},
			"utf8": {},
		},
	};
});